from odoo import models, fields

class TonKhoReport(models.Model):
    _name = 'ton.kho.report'
    _description = 'Báo Cáo Tồn Kho'

    product_id = fields.Many2one('product.product', string='Sản phẩm')
    quantity = fields.Float(string='Số lượng')
    location_id = fields.Many2one('stock.location', string='Vị trí kho')

