{
    'name': 'Stock_Inventory_Report',
    'version': '1.0',
    'summary': 'Custom stock report',
    'depends': ['stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/stock_report_views.xml',
    ],
    'installable': True,
    'application': False,
}
